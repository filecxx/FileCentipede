Action#act_check_on
{
	text:"${checkbox_on}"
    icon:"icons/16/none.svg"
}

Action#act_uncheck_off
{
	text:"${checkbox_off}"
    icon:"icons/16/none.svg"
}

Action#act_check_all
{
	text:"${checkbox_on_all}"
    icon:"icons/16/none.svg"
}

Action#act_uncheck_all
{
	text:"${checkbox_off_all}"
    icon:"icons/16/none.svg"
}

Menu#context_menu
{
    ${#act_check_on}
    ${#act_uncheck_off}
    ${#act_check_all}
    ${#act_uncheck_all}
}

CheckBox#video_audio_merge
{
    name: video_audio_merge
    text: "${merge} ${video} + ${audio}"
}


///-------------------------
#attributes
{
    text:"${attributes}"
    layout:VBoxLayout
    

    Widget#loading
    {
        css:"background:transparent"
        layout:{
            type:VBoxLayout
            align:hcenter
        }
        <==>
        Img{src:"ui/css/images/loading_clock.gif"}
        "${downloading_metadata}"
        <==>
    }

    DetailBar#files_panel
    {
        //default: 0
        visible: true
        spacing: 4
        corner: ${#video_audio_merge}

        {
            subset:segments
            text:"TS"
            icon-size:24
            icon:"icons/mimetypes/24/video-mp2t.png"
            visible: false
            layout:{
                type:VBoxLayout
                margin: 0
            }
            
            FileSystem#files_ts
            {
                sortable:true
                stripe:true
                editable:false
                checkable:true
                selection:rows
                icon-size:24
                context-menu:${#context_menu}
                columns-height:26
                columns:{
                    {name:file_name,text:"${name}",width:240}
                    {name:segments,text:"${segments}",width:80}
                    {name:duration_length,text:"${duration_length}",format:"duration=d",width:110}
                }
            }
        }

        {
            subset:videos
            text:"${video}"
            icon-size:24
            icon:"icons/mimetypes/24/video-mp4.png"
            visible: false
            layout:{
                type:VBoxLayout
                margin: 0
            }
            FileSystem#files_video
            {
                sortable:true
                stripe:true
                editable:false
                checkable:true
                selection:rows
                icon-size:24
                context-menu:${#context_menu}
                columns-height:26
                columns:{
                    {name:file_name,text:"${name}",width:240}
                    {name:resolution_size,text:"${resolution_size}",width:110}
                    {name:duration_length,text:"${duration_length}",format:"duration=d",width:110}
                    {name:codec,text:"${codec}",width:110}
                }
            }
        }

        {
            subset:audios
            text:"${audio}"
            icon-size:24
            icon:"icons/mimetypes/24/audio-mp3.png"
            visible: false
            layout:{
                type:VBoxLayout
                margin: 0
            }
            FileSystem#files_audio
            {
                sortable:true
                stripe:true
                editable:false
                checkable:true
                selection:rows
                icon-size:24
                context-menu:${#context_menu}
                columns-height:26
                columns:{
                    {name:file_name,text:"${name}",width:240}
                    {name:lang,text:"${language}",width:110}
                    {name:duration_length,text:"${duration_length}",format:"duration=d",width:140}
                    {name:codec,text:"${codec}",width:100}
                }
            }
        }

        {
            subset:subtitles
            text:"${subtitle}"
            icon-size:24
            icon:"icons/mimetypes/24/text-x-generic.png"
            visible: false
            layout:{
                type:VBoxLayout
                margin: 0
            }
               
            FileSystem#files_subtitle
            {
                sortable:true
                stripe:true
                editable:false
                checkable:true
                selection:rows
                icon-size:24
                context-menu:${#context_menu}
                columns-height:26
                columns:{
                    {name:file_name,text:"${name}",width:240}
                    {name:lang,text:"${language}",width:120}
                }
            }
        }
    }

    GridLayout
    {
        column:2

        "${address}:" HBoxLayout
        {
            LineEdit#address
            {
                name:uri
                readonly:true
            }
            ToolButton{
                icon:"icons/16/copy.svg"
                click:$copy(${#address})
            }
        }
        "${page_url}:" HBoxLayout
        {
            LineEdit#page_url
            {
                name:page_url
            }
            ToolButton{
                icon:"icons/16/web.svg"
                click:$open-url(${#page_url})
            }
        }

        "${file_name}:" HBoxLayout
        {
            LineEdit{
                name:file_name
            }
            "${catalog}:" ComboBox#catalog{
                name:catalog
                vtype:data
                editable:false
                icon-size:16
                
                "  ---  "
            }
        }
        "${save_path}:" HBoxLayout
        {
            ComboBox#save_path
            {
                name:save_path
                vtype:text
                editable:true
                stretch:"expand"
                placeholder:"${save_path_placeholder}"
                items:$filec-paths()
            }
            Button{
                text:"..."
                click:$select-dir("${save_path}",${#save_path})
            }
        }
                    
        "${proxy}:" HBoxLayout
        {
            ComboBox#proxy{
                name:proxy
                vtype:data
                editable:false
                
                {
                    text:"${no_proxy}"
                    data:0
                }
                {
                    text:"${OS_setting}"
                    data:"@os"
                }
            }
            ComboBox{
                name:proxy_mode
                editable:false
                vtype:index
                
                "${always}"
                "${if_available}"
                "${as_backup}"
                "${round_robin}"
            }
        
            <==>
        }
        
    }
}

#settings
{
    text:"${settings}"
    layout:VBoxLayout
    
    GridLayout
    {
        column:6
  
        "${connect_timeout}:" SpinBox{
            name:connect_timeout
            max:120000
            step:1000
            suffix:ms
        }
        "${max_connections}:" ComboBox{
            name:max_connections
            vtype:number
            editable:true
            max:1024
            1 2 4 8 16 32 64 128 256 512
        }
        "${max_retry}:" SpinBox{
            name:max_retry
            min:0
            max:9999
        }
        "${max_redirect}:" SpinBox{
            name:max_redirect
            max:20
        }
        "${speed_limit_download}:" SpinBox{
            name:speed_limit_download
            max:9999999
            suffix:KB
            step:100
            special-text:"${unlimited}"
        }
        "${speed_limit_upload}:" SpinBox{
            name:speed_limit_upload
            max:9999999
            suffix:KB
            step:100
            special-text:"${unlimited}"
        }
    }

    GroupBox
    {
        title:"${attributes}"
        layout:HBoxLayout

        HBoxLayout
        {
            "${parallel}(${connections}): " ComboBox{
                name:parallel
    
                vtype:index
                "${smooth}"
                "${fastest}"
            }
            <==>
        }
        /*
        HBoxLayout
        {
            "${merge_method}: " ComboBox{
                name: merge_method
    
                vtype:index
                "${fastest}"
                "${transcoding}"
                
            }
            <==>
        }
        */
        <==>
    }
    GroupBox
    {
        title:"${behavior}"
        layout:{
            type:GridLayout
            column:4
        }

        CheckBox{
            name:ignore_server_busy
            text:"${ignore_server_busy}"
        }
        CheckBox{
            name:auto_rename_file
            text:"${auto_rename_file}"
        }
        CheckBox{
            name:auto_merge
            text:"${merge_segments}"
        }
        CheckBox{
            name:no_task_record
            text:"${no_task_record}"
        }
    }
    <==>
}

#cookie
{
    text:"Cookie"
    layout:{
        type:VBoxLayout
    }
    TextEdit{
        name:cookies
        placeholder:"${http_header_placeholder}"
    }
}

#headers
{
    text:"Headers"
    layout:{
        type:GridLayout
        column: 2
    }
    GridLayout
    {
        column: 2

        "User Agent:" ComboBox#user_agents{
            name:user_agent
            vtype:text
            editable:true
            size-adjust:minimum
            items:$filec-user-agents()
        }

        "Headers:" TextEdit{
            name:headers
            placeholder:"${http_cookie_placeholder}"
        }
    
    }
}

#decryption
{
    text:"${decryption}"
    layout:{
        type:VBoxLayout
    }
    GridLayout
    {
        column:2

        "${base_url}:" LineEdit{
            name:base_url
            placeholder:"${optional}"
        }
        "Key: " HBoxLayout{
            LineEdit{
                name:key_data
                placeholder:"${optional}"
            }
            ComboBox{
                vtype:index
                name:key_mode
                Base64
            }
        }
        "IV (HEX): " HBoxLayout{
            LineEdit{
                name:iv
                placeholder:"${optional}"
            }
        }
    }
    <==>
}

#metadata
{
    text:"${metadata}"
    layout:{
        type:VBoxLayout
    }
    TextEdit#metadata_text
    {
        readonly: true
    }
}


Dialog#main
{
    title:"${add_task}"
    layout:VBoxLayout
    w:750
    h:550
    
    Tab
    {
        ${#attributes}
        ${#settings}
        ${#cookie}
        ${#headers}
        ${#decryption}
        ${#metadata}
    }
    HBoxLayout
    {
        CheckBox#without_confirm{
            text:"${dont_show_this_again}"
        }
        <==>
        Button{
            icon:"icons/16/close.svg"
            text:"${cancel}"
            click:$close{#main}()
        }
        Button#download_later{
            icon:"icons/16/delay.svg"
            text:"${download_later}"
        }
        Button#download_now{
            icon:"icons/16/download.svg"
            text:"${download_now}"
        }
    }
}
 
