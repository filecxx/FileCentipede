DetailBar#details
{
}
