DetailBar#details
{
    expanded:false
    {
        subset:attributes
        text:"${attributes}"
        icon-size:16
        icon:"icons/16/attributes.svg"
        layout:{
            type:VBoxLayout
            margin:8
        }
        GridLayout
        {
            column:6
            
            "${catalog}:" LineView{name:catalog}
            "${size}:" LineView{name:file_size,format:bytes}
            "${downloaded}:" LineView{name:downloaded,format:bytes}
            "${uploaded}:" LineView{name:uploaded,format:bytes}
            "${connectivity}:" LineView{name:connectivity}
            "${connect_timeout}:" LineView{name:connect_timeout,format:"number ms"}
            "${connections}:" LineView{name:connections}
            "${max_connections}:" LineView{name:max_connections}
            "${max_retry}:" LineView{name:max_retry}
            "${speed_limit_download}:" LineView{name:speed_limit_download,format:"number KB/s"}
            "${speed_limit_upload}:" LineView{name:speed_limit_upload,format:"number KB/s"}
            "${resumable}:" LineView{name:resumable}
            "${auto_rename_file}:" LineView{name:auto_rename_file}
            "${ignore_server_busy}:" LineView{name:ignore_server_busy}
            "${time_create}:" LineView{name:time_create,format:datetime}
            "${time_start}:" LineView{name:time_start,format:datetime}
            "${time_end}:" LineView{name:time_end,format:datetime}
        }
  
    }
    {
        subset:request
        text:"${request}"
        icon-size:16
        icon:"icons/16/request.svg"
        layout:VBoxLayout
        
        GridLayout
        {
            column:2
     
            "${proxy}:" LineView{name:proxy}
            "${proxy_mode}:" LineView{name:proxy_mode}

            "${address}:" LineEdit{
                name:uri
                readonly:true
            }
            "${page_url}:" HBoxLayout
            {
                LineEdit#page_url{
                    name:page_url
                    readonly:true
                }
                ToolButton{
                    icon:"icons/24/web.svg"
                    click:$open-url(${#page_url})
                }
            }
            "${message}" TextEdit{
                name:message
                readonly:true
            }
        }
    }
    {
        subset:connections
        text:"${connections}"
        icon-size:16
        icon:"icons/16/connect.svg"
        layout:{
            type:VBoxLayout
            margin:1
        }
        Table.table#connections
        {
            sortable:true
            stripe:true
            editable:false
            grid:false
            numbers:true
            selection:rows
            min-height:100
            columns:{
                {name:"state",width:140,text:"${state}"}
                {name:"begin",width:120,text:"${begin}",format:bytes}
                {name:"end",width:120,text:"${end}",format:bytes}
                {name:"transferred",width:120,text:"${transferred}",format:bytes}
                {name:"progress",width:100,text:"${progress}", format:"progress",align:"right"}
                {name:"speed", text:"${speed}", width:100, format:"bytes/s",align:"right"}
                {name:"proxy",width:120,text:"${proxy}",align:"center"}
            }
        }
    }
    {
        subset:blocks
        text:"${blocks}"
        icon-size:16
        icon:"icons/16/blocks.svg"
        layout:{
            type:VBoxLayout
            margin:1
        }
        Blocks{
            min-height:120
            name:blocks
        }
    }
}
