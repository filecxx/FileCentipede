Dialog#main
{
    layout:VBoxLayout
}
