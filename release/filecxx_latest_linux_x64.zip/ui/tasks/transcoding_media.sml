Dialog#main
{
    title:"${transcoding}"
    layout:VBoxLayout
    w:620
    h:160

    Widget#loading
    {
        css:"background:transparent"
        layout:{
            type:VBoxLayout
            column:1
            align:hcenter
        }
        visible: false
        Img{src:"ui/css/images/loading_clock.gif"}
        "${transcoding}"
    }
    GroupBox#path_group
    {
        title:"${path}"
        layout:GridLayout
        column:2

        "${path}:" LineEdit#path{name:path,readonly:true}
        "${save_as}:" HBoxLayout{
            LineEdit#save_as{name:save_as}
            Button#save_as_btn{text:"..."}
        }
    }

    GroupBox
    {
        title:"${options}"
        layout:HBoxLayout
 
        CheckBox#delete_origin_file{
            name: delete_origin_file
            text: "${delete_origin_file}"
            value: true
        }
        CheckBox#close_after_finished{
            text: "${close_the_dialog_after_finished}"
            value: true
        }
    }
    
    HBoxLayout
    {
        Button{
            text:"${cancel}"
            icon:"icons/16/close.svg"
            click:$close{#main}()
        }
        <==>
        Button#open_directory{
            text:"${open_directory}"
            icon:"icons/16/directory.svg"
        }
        Button#exec{
            text:"${transcoding}"
            icon:"icons/16/transfer.svg"
        }
    }
} 
