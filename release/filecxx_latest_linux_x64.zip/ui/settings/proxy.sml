Action#act_proxy_add
{
    text:"${add}"
    icon:"icons/24/add.svg"
    shortcut:"Ctrl+N"
}

Action#act_proxy_edit
{
    text:"${edit}"
    icon:"icons/24/edit.svg"
    shortcut:"Ctrl+E"
}

Action#act_proxy_remove
{
    text:"${remove}"
    icon:"icons/24/delete.svg"
    shortcut:"Del"
}

Action#act_proxy_copy
{
    text:"${copy}"
    icon:"icons/24/save.svg"
    shortcut:"Ctrl+C"
}

Action#act_proxy_import
{
    text:"${import}"
    icon:"icons/24/import.svg"
    enable:false
}

Action#act_proxy_export
{
    text:"${export}"
    icon:"icons/24/export.svg"
    enable:false
}

Action#act_proxy_test
{
    text:"${test}"
    icon:"icons/16/ok.svg"
}


///-----------------------
Action#act_extract_add
{
    text:"${add}"
    icon:"icons/24/add.svg"
    shortcut:"Ctrl+N"
    trigger:{
        $clear{#dialog_add_extract TextEdit}()
        $exec{#dialog_add_extract}()
    }
}

Action#act_extract_clear
{
    text:"${clear}"
    icon:"icons/24/delete_all.svg"
}

Action#act_extract_copy
{
    text:"${copy}"
    icon:"icons/24/save.svg"
}

Action#act_extract_copy_all
{
    text:"${copy_all}"
    icon:"icons/24/save.svg"
}


///-----------------------
Action#act_subscribe_add
{
    text:"${add}"
    icon:"icons/24/add.svg"
}

Action#act_subscribe_edit
{
    text:"${edit}"
    icon:"icons/24/edit.svg"
}

Action#act_subscribe_remove
{
    text:"${remove}"
    icon:"icons/24/delete.svg"
}

Action#act_subscribe_import
{
    text:"${import}"
    icon:"icons/24/import.svg"
    enable:false
}

Action#act_subscribe_export
{
    text:"${export}"
    icon:"icons/24/export.svg"
    enable:false
}

Action#act_subscribe_update
{
    text:"${update}"
    icon:"icons/16/update.svg"
}


///-----------------------
Dialog#dialog_add_extract
{
    title:"${batch_test_extract}"
    layout:VBoxLayout
    width:600
    height:300
    
    TextEdit{
        name:content
        placeholder:"${proxy_extract_text_}"
    }
    HBoxLayout
    {
        "${target} (${test}):" LineEdit{
            name:target
            value:"https://debian.org"
        }
    }
    HBoxLayout{
        <==>
        Button#add_extract{
            text:"${test}"
        }
    }
}


///-----------------------
EditDialog#dialog_edit
{
    width:300
    height:200
    title-add:"${add}"
    title-edit:"${edit}"
    form:${#dialog_edit}
    layout:VBoxLayout
    buttons:default
    GridLayout
    {
        column:2

        "${type}:" ComboBox{
            name:type
            vtype:text
            size-adjust:content
            current:0
            
            SOCKS5
            HTTP
            HTTPS
            SOCKS5S
        }
        "${name}:" LineEdit{
            name:name
            placeholder:"${name}"
        }
        "${host}:" LineEdit{
            name:host
            value:"127.0.0.1"
            placeholder:"IP / ${domain}"
        }
        "${port}:" SpinBox{
            name:port
            min:1
            max:65535
            1080
        }
        
        "${user}:" LineEdit{
            name:user
            placeholder:"${optional}"
        }
        "${password}:" LineEdit{
            name:pass
            type:password
            placeholder:"${optional}"
        }
    }
}

#proxies_list
{
    text:"${proxies}"
    layout:{
        type:VBoxLayout
        spacing:0
        margin:2
    }
    ToolBar
    {
        icon-size:24
        button-style:TextBesideIcon
        
        ${#act_proxy_add}
        ${#act_proxy_edit}
        ${#act_proxy_remove}
        ${#act_proxy_copy}
        ---
        /*
        ${#act_proxy_import}
        ${#act_proxy_export}
        ---
        */
        ${#act_proxy_test}
        
    }
    Table#proxies
    {
        sortable:true
        editable:false
        stripe:true
        stretch:expand
        stretch-last-section:true
        selection:rows
        columns-height:26
        columns:{
            {name:name,text:"${name}",width:100}
            {name:type,text:"${type}",width:80}
            {name:host,text:"${host}",width:120}
            {name:port,text:"${port}",width:60}
            {name:user,text:"${user}"}
            {name:pass,text:"${password}"}
            {name:state,text:""}
        }
        double-click:$trigger{#act_proxy_edit}()
        context-menu:{
            ${#act_proxy_add}
            ${#act_proxy_edit}
            ${#act_proxy_remove}
            ---
            ${#act_proxy_import}
            ${#act_proxy_export}
        }
    }
}


#proxies_extract
{
    text:"${batch_test_extract}"
    layout:{
        type:VBoxLayout
        spacing:0
        margin:2
    }
    ToolBar
    {
        icon-size:24
        button-style:TextBesideIcon

        ${#act_extract_add}
        ${#act_extract_clear}
        ---
        
        ${#act_extract_copy}
        ${#act_extract_copy_all}
    }
    
    Table#extract_list
    {
        sortable:true
        editable:true
        stripe:true
        stretch:expand
        stretch-last-section:true
        selection:rows
        columns-height:26
        columns:{
            {name:type,text:"${type}",width:120}
            {name:host,text:"${host}",width:160}
            {name:port,text:"${port}",width:80}
            {name:received_length,text:"${received_length}",width:140,format:bytes}
            {name:delay,text:"${delay}",width:140}
        }
    }
    StatusBar#extract_status{
        message: "${fake_proxy_tips_}"
        message-timeout: 9999999
    }
}

#proxies_subscribe
{
    text:"${subscribe}"
    layout:{
        type:VBoxLayout
        spacing:0
        margin:2
    }
    ToolBar
    {
        icon-size:24
        button-style:TextBesideIcon

        ${#act_subscribe_add}
        ${#act_subscribe_edit}
        ${#act_subscribe_remove}
        ---
        ${#act_subscribe_update}

    }
    
    Table#subscribes
    {
        sortable:true
        editable:false
        stripe:true
        stretch:expand
        stretch-last-section:true
        selection:rows
        columns-height:26
        columns:{
            {name:url,text:"URL",width:280}
            {name:uptime,text:"${format}",width:100}
            {name:uptime,text:"${uptime}",width:140}
            {name:state,text:""}
        }
        double-click:$trigger{#act_subscribe_edit}()
        context-menu:{
            ${#act_subscribe_add}
            ${#act_subscribe_edit}
            ${#act_subscribe_remove}
            ---
            ${#act_subscribe_import}
            ${#act_subscribe_export}
        }
    }

}

Dialog#main
{
    title:"${proxies}"
    layout:VBoxLayout
    width:720
    height:450
    Tab{
        ${#proxies_list}
        ${#proxies_extract}
        //${#proxies_subscribe}
    }
    
   
}  
