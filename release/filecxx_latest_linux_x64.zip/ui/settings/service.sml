#page_service_help
{
    text:"${help}"
    layout:VBoxLayout

    Label
    {
        wordwrap:true
        css:"color:gray"
        
        "${service_description_}"
    }
    <==>
}

#page_service
{
    text:"${settings}"
    layout:VBoxLayout
    
    GroupBox
    {
        title:"${options}"
        layout:HBoxLayout
       
        "${state}:" ComboBox{
            name:enable
            min-width:80
            vtype:index
            
            "${disable}"
            "${enable}"
        }
        "${remote_access}:" ComboBox{
            name:remote_access
            min-width:80
            vtype:index
            
            "${disable}"
            "${enable}"
        }
        <==>
        
    }
    
    GroupBox
    {
        title:"Server"
        layout:{
            type:GridLayout
            column:3
        }

        "HTTP Server:" ComboBox{
            name:webserver
            min-width:80
            vtype:index
            
            "${disable}"
            "${enable}"
        }

        HBoxLayout{
            "${dir_listing}: " ComboBox{
                name:webserver_dir_listing
                min-width:80
                vtype:index
                
                "${disable}"
                "${enable}"
            }
            ToolButton#open_webserver_url{
                icon: "icons/16/directory.svg",
                click:$open-local-url("${__workspace__}www")
            }
            ToolButton#open_webserver_url{
                icon: "icons/16/web.svg",
                click: $open-url("http://127.0.0.1:10111")
            }
           
            <==>
        }
     
        "WebDAV Server:" ComboBox{
            name:webdav
            enable: false
            min-width:80
            vtype:index
            "${disable}"
            "${enable}"
        }
        HBoxLayout{
            <==>
        }
        
        
        "${proxy_server} :" ComboBox{
            enable: false
            min-width:80
            vtype:index
            "${disable}"
            "${enable}"
        }
        HBoxLayout{
            <==>
        }
    }

    GroupBox
    {
        title:"${access}"
        layout:VBoxLayout
        
        Label
        {
            wordwrap:true
            "${notice}: (${service_port_notice_})"
        }
        
        GridLayout
        {
            column:4
   
            "${username}:" LineEdit{
                name:username
                placeholder:"${optional}"
            }
            "${password}:" LineEdit{
                name:password
                type:pw
                placeholder:"${optional}"
            }
                     
            "${port}:" SpinBox{
                name:port
                min:1025
                max:65535
                value:10111
            }
            "",""
        }

        CheckBox{
            name:skip_localhost_pass
            text:"${skip_localhost_password_authentication}"
            value:true
        }
        CheckBox{
            name:skip_http_server_auth
            text:"${skip_http_server_authentication}"
            value:true
        }


    }
    <==>
}

#page_rpc
{
    text:"RPC"
    layout:VBoxLayout
}


Widget#service
{
    layout:{
        type:VBoxLayout
        margin:0
    }
    Tab{
        ${#page_service}
        //${#page_rpc}
        ${#page_service_help}
    }
   
}
