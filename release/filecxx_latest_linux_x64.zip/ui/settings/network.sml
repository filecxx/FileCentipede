#page_network
{
    text:"${settings}"
    layout:VBoxLayout
    
    GroupBox
    {
        title:"${options}"
        layout:VBoxLayout

        GridLayout
        {
            column:4
            "${client_name}:" ComboBox{
                name:client_name
                editable:true
                stretch:expand
                vtype:text

                ""
                "filecxx/${__version__}"
                "uTorrent 2.2.1"
                "qBittorrent/4.3.8"
                "Transmission/2.77"
                "Transmission 3.00"
                "µTorrent 3.5.5"
                "BitComet 1.8.2"
                "libtorrent/1.2.2.0"
                "BitSpirit v3.6.0"
            }
            "${client_fingerprint}: " ComboBox{
                name:client_fingerprint_type
                editable:false
                vtype:index

                "${default}"
                "${customize}"
            }
            "${encrypt_mode}:" ComboBox{
                name:encrypt_mode
                stretch:expand
                vtype:index

                "${force_encrypt}"
                "${allow_encrypt}"
                "${disable_encrypt}"
            }

            "${upload_algorithm}:" ComboBox{
                name:upload_algorithm
                stretch:expand
                vtype:index

                "${round_robin}"
                "${fastest_upload}"
                "${anti_leech}"
            }
            "Torrent ${port}:" SpinBox{
                name:torrent_port
                min:0
                max:65535
                special-text:"${random}"
            }
        }
        HBoxLayout
        {
            LineEdit#client_fingerprint{
                name:client_fingerprint
                placeholder:"${client_fingerprint} (URI ${encoded})"
            }
            ComboBox#client_fingerprint_preset
            {
                vtype:data
                value:0
                size-adjust:content

                change:$value{#client_fingerprint}($value{#client_fingerprint_preset}())
                {
                    text:"${customize}"
                    data:""
                }
                {
                    text:"uTorrent 2.2.1"
                    data:"UT2210-%d6bE%c7L7%d8%aeD1%1e%c3"
                }
                {
                    text:"Transmission/2.77"
                    data:"TR2770-8u%13Y%CB9%D3%CE%F6mF%0A"
                }
                {
                    text:"rTorrent/0.9.4/0.13.4"
                    data:"TR2940-tyyz4k6tzpz2"
                }
            }
            A{
                link:"https://wiki.theory.org/BitTorrentSpecification#peer_id"
                "(?)"
            }

        }

    }
    GroupBox
    {
        title:"${proxy} && ${adapter}"
        layout:VBoxLayout

        HBoxLayout
        {
            "${proxy}:" ComboBox#network_proxy{
                name:proxy
                vtype:data
                stretch:expand
                editable:false
            }
            ComboBox{
                name:proxy_mode
                editable:false
                vtype:index

                "${always}"
                "${if_available}"
                "${as_backup}"
                "${round_robin}"
            }
            ToolButton#show_proxies{
                icon:"icons/16/proxy.svg"
            }
        }
        HBoxLayout
        {

        }

    }
    GroupBox
    {
        title:"${options}"
        layout:{
            type:GridLayout
            column:4
        }

        CheckBox{
            text:"${anonymous_mode}"
            name:anonymous_mode
        }
        CheckBox{
            name:torrent_enable_proxy
            text:"Torrent ${enable_proxy}"
        }
        CheckBox{
            name:enable_DHT
            text:"${enable} DHT"
        }
        CheckBox{
            name:enable_LSD
            text:"${enable} LSD"
        }
        CheckBox{
            text:"P2P ${enable_proxy}"
            enable:false
        }
    }
    GroupBox
    {
        layout:HBoxLayout
        title:"${nat_port_mapping}"

        CheckBox{
            name:enable_upnp
            text:"${enable_upnp}"
        }
        CheckBox{
            name:enable_natpmp
            text:"${enable_natpmp}"
        }
    }
    GroupBox
    {
        title:"${tasks}"
        layout:{
            type:GridLayout
            column:2
        }
        HBoxLayout
        {
            "${max_downloading_tasks}:" SpinBox{
                name:max_downloading_tasks
                min:0
                max:2147483647
                special-text:"${unlimited}"
            }
            <==>
        }
        HBoxLayout
        {
            "${max_uploading_tasks}:" SpinBox{
                name:max_uploading_tasks
                min:0
                max:2147483647
                special-text:"${unlimited}"
            }
            <==>
        }
    }
    
    <==>
}


Tab#network
{
    visible:false
    ${#page_network}
}

