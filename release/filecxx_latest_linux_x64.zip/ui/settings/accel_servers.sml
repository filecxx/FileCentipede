Action#act_http_mirror_add
{
    text:"${add}"
    icon:"icons/24/add.svg"
    shortcut:"Ctrl+N"
}

Action#act_http_mirror_edit
{
    text:"${edit}"
    icon:"icons/16/edit.svg"
    shortcut:"Ctrl+E"
}

Action#act_http_mirror_remove
{
    text:"${remove}"
    icon:"icons/16/delete.svg"
    shortcut:"Del"
}

Action#act_http_mirror_copy
{
    text:"${copy}"
    icon:"icons/16/copy.svg"
    shortcut:"Ctrl+C"
}

Action#act_http_mirror_paste
{
    text:"${paste}"
    icon:"icons/16/paste.svg"
    shortcut:"Ctrl+V"
    trigger:{
        $clear{#dialog_http_mirror_paste TextEdit}()
        $exec{#dialog_http_mirror_paste}()
    }
}


/*
Action#act_torrent_server_add
{
    text:"${add}"
    icon:"icons/24/add.svg"
}

Action#act_torrent_server_edit
{
    text:"${edit}"
    icon:"icons/16/edit.svg"
}

Action#act_torrent_server_remove
{
    text:"${remove}"
    icon:"icons/16/delete.svg"
}

Action#act_torrent_server_test
{
    text:"${test}"
    icon:"icons/16/ok.svg"
}
*/

Dialog#dialog_http_mirror_paste
{
    title:"${paste}"
    layout:VBoxLayout
    width:600
    height:300
    
    TextEdit{
        name:text
    }
    HBoxLayout{
        <==>
        Button#http_mirror_paste_rules{
            text:"${OK}"
        }
        Button{
            text:"${cancel}"
            click:$close{#dialog_http_mirror_paste}()
        }
    }
}


#http_mirror_servers_page
{
    text:"HTTP ${mirror_servers}"
    icon:"icons/16/web.svg"
    layout:{
        type:VBoxLayout
        spacing:0
        margin:2
    }
    ToolBar
    {
        icon-size:16
        button-style:TextBesideIcon

        ${#act_http_mirror_add}
        ${#act_http_mirror_edit}
        ${#act_http_mirror_remove}
        ---
        ${#act_http_mirror_copy}
        ${#act_http_mirror_paste}
    }
    Table#mirror_servers
    {
        sortable:true
        editable:false
        stripe:true
        stretch:expand
        stretch-last-section:true
        selection:rows
        columns-height:26
        columns:{
            {name:name,text:"${name}",width:160}
            {name:host,text:"${host}",width:160}
            {name:mode,text:"${mode}",width:140}
            {name:proxy,text:"${proxy}",width:100}
            {name:path,text:"${path}",width:160}
        }
        double-click:$trigger{#act_http_mirror_edit}()
        context-menu:{
            ${#act_http_mirror_add}
            ${#act_http_mirror_edit}
            ${#act_http_mirror_remove}
            ---
            ${#act_http_mirror_copy}
            ${#act_http_mirror_paste}
        }
    }
}
/*
#torrent_servers_page
{
    text:"${torrent_servers}"
    layout:{
        type:VBoxLayout
        spacing:0
        margin:2
    }
    ToolBar
    {
        icon-size:18
        button-style:TextBesideIcon

        ${#act_torrent_server_add}
        ${#act_torrent_server_edit}
        ${#act_torrent_server_remove}
        ---

        ${#act_torrent_server_test}

    }
    Table#mirror_servers
    {
        sortable:true
        editable:false
        stripe:true
        stretch:expand
        stretch-last-section:true
        selection:rows
        columns-height:26
        columns:{
            {name:name,text:"${name}",width:100}
            {name:type,text:"${type}",width:80}
            {name:host,text:"${host}",width:120}
            {name:port,text:"${port}",width:60}
            {name:state,text:""}
        }
        double-click:$trigger{#act_torrent_server_edit}()
        context-menu:{
            ${#act_torrent_server_add}
            ${#act_torrent_server_edit}
            ${#act_torrent_server_remove}
        }
    }
}

#help_page
{
    text:"${help}"
    layout:{
        type:VBoxLayout
        spacing:0
        margin:2
    }
}
*/


Dialog#main
{
    title:"${accel_servers}"
    layout:VBoxLayout
    width:800
    height:500
    Tab{
        ${#http_mirror_servers_page}
        //${#torrent_servers_page}
        ${#help_page}
    }
}
