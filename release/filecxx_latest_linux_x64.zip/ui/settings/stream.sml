#page_stream_task_attr
{
    text:"${task}"
    layout:VBoxLayout
    
    GroupBox
    {
        title:"${options}"
        layout:{
            type:GridLayout
            column:4
        }

        "${connect_timeout}:" SpinBox{
            name:connect_timeout
            value:5000
            min:10
            max:120000
            step:1000
            suffix:ms
        }
        
        "${max_connections}:" ComboBox{
            name:max_connections
            vtype:number
            editable:true
            value:8
            1 2 4 8 16 32 64
        }
        
        "${max_retry}:" SpinBox{
            name:max_retry
            min:0
            max:9999
        }
        
        "${max_redirect}:" SpinBox{
            name:max_redirect
            max:20
        }
        
        "${speed_limit_download}:" SpinBox{
            name:speed_limit_download
            max:9999999
            suffix:KB
            step:100
            special-text:"${unlimited}"
        }
        
        "${speed_limit_upload}:" SpinBox{
            name:speed_limit_upload
            max:9999999
            suffix:KB
            step:100
            special-text:"${unlimited}"
        }
        
    }

    
    GroupBox
    {
        title:"${attributes}"
        layout:HBoxLayout

        HBoxLayout
        {
            "${parallel}(${connections}): " ComboBox{
                name:parallel
    
                vtype:index
                "${smooth}"
                "${fastest}"
            }
        }
        /*
        <==>
        HBoxLayout
        {
            "${merge_method}: " ComboBox{
                name: merge_method
    
                vtype:index
                "${fastest}"
                "${transcoding}"
            }
        }
        */
     
        HBoxLayout
        {
            "${preferred_video_quality} : " ComboBox{
                name: preferred_video_quality
                vtype:index
                "${all}"
                ">= 240p"
                ">= 360p"
                ">= 480p"
                ">= 720p"
                ">= 1080p"
                ">= 2K"
                ">= 4K"
                ">= 8K"
            }
        }
        <==>
    }
    GroupBox
    {
        title:"${behavior}"
        layout:{
            type:GridLayout
            column:3
        }

        CheckBox{
            name:ignore_server_busy
            text:"${ignore_server_busy}"
        }
        CheckBox{
            name:auto_rename_file
            text:"${auto_rename_file}"
            value:true
        }
        CheckBox{
            name:auto_merge
            text:"${merge_segments}"
            value:true
        }
        CheckBox#video_audio_merge
        {
            name:video_audio_merge
            text: "${merge} ${video} + ${audio}"
        }
        CheckBox{
            name:without_confirm
            text:"${without_confirm}"
        }
        CheckBox{
            name:no_task_record
            text:"${no_task_record}"
        }
    }
    <==>
}

#page_stream_task_headers
{
    text:"Headers"
    layout:VBoxLayout

    HBoxLayout{
        "User Agent:" 
    }
    HBoxLayout
    {
        ComboBox{
            name:user_agent
            vtype:text
            editable:true
            size-adjust:minimum
            items:$filec-user-agents()
        }
    }
    "Headers:" TextEdit{
        name:headers
        placeholder:"${http_header_placeholder}"
    }
}


Tab#page_stream_task
{
    ${#page_stream_task_attr}
    ${#page_stream_task_headers}
} 

Widget#stream
{
    visible:false
    layout:{
        type:VBoxLayout
        margin:0
    }
    ${#page_stream_task}
}

 
