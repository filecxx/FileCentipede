# External Message API

The filecxx browser extension provides an API for external scripts and browser extensions to add media items and query resources detected by the extension.

---
## 1. Add Media

Send media information to the extension. The submitted item will appear in the extension's popup list.

### Example

```js
window.dispatchEvent(new CustomEvent("filecxx_add_media", {
    detail: {
        media_type: "mp4",              // string, required
        url: "http://localhost/1.mp4",  // string, required
        audio_type: false,              // boolean, optional
        page_url: "http://localhost",   // string, optional
        size: 1024,                     // number, optional
        duration: 120,                  // number, optional
        text: "HD 1080P",               // string, optional
        file_name: "123",               // string, optional, without extension
        referer: "http://localhost",    // string, optional
        cookie: "",                     // string, optional
        header: {}                      // object or string, optional
    }
}));
```

### Parameters

| Parameter    | Type               | Required | Description                                                        |
|--------------|--------------------|----------|--------------------------------------------------------------------|
| `media_type` | `string`           | Yes      | Media format, such as `m3u8`, `mpd`, or `mp4`.                     |
| `url`        | `string`           | Yes      | Media resource URL.                                                |
| `audio_type` | `boolean`          | No       | Whether the resource is audio.                                     |
| `page_url`   | `string`           | No       | URL of the page containing the resource.                           |
| `size`       | `number`           | No       | Resource size in bytes.                                            |
| `duration`   | `number`           | No       | Media duration in seconds.                                         |
| `text`       | `string`           | No       | Display text. Optional when `size` or `duration` is provided.      |
| `file_name`  | `string`           | No       | Suggested filename without the extension.                          |
| `referer`    | `string`           | No       | Referer URL to use when accessing the resource.                    |
| `cookie`     | `string`           | No       | Cookie header value.                                               |
| `header`     | `object \| string` | No       | Additional HTTP headers, specified as key-value pairs or a string. |

---
## 2. Query Extension Data

Use `filecxx_query(act, callback)` to retrieve data already collected by the extension.

### Function

```js
function filecxx_query(act, callback)
{
    const { port1, port2 } = new MessageChannel();

    const timer = setTimeout(function() {
        port1.close();
        callback({ error: "timeout" });
    }, 2000);

    port1.onmessage = (e) => {
        clearTimeout(timer);
        port1.close();
        callback(e.data);
    };

    window.postMessage({ act: act }, "*", [port2]);
}
```

**Parameters**

| Parameter  | Type       | Description                             |
|------------|------------|-----------------------------------------|
| `act`      | `string`   | Query action.                           |
| `callback` | `function` | Callback invoked with the query result. |

**Error handling**

- `error: "OK"` — The query succeeded.
- `error: "disabled"` — External messages are disabled in the extension settings.
- `error: "timeout"` — No response was received within 2 seconds.

### 2.1. Query Media

Retrieve detected media information, including videos, audio, and potential video URLs or keys.

**Action:** `filecxx_query_medias`

**Example**

```js
filecxx_query("filecxx_query_medias", (result) => {
    console.log(result);
});
```

**Result object**

| Property           | Type     | Description                                                 |
|--------------------|----------|-------------------------------------------------------------|
| `error`            | `string` | Query status. `"OK"` indicates success.                     |
| `videos`           | `object` | Detected video information.                                 |
| `videos_uncertain` | `object` | Video information that has not been confidently identified. |
| `audios`           | `object` | Detected audio information.                                 |
| `potential_keys`   | `object` | Potential video-related keys.                               |
| `potential_urls`   | `object` | Potential video URLs or key URLs.                           |

### 2.2. Query Resources

Retrieve resource files detected by the extension.

**Action:** `filecxx_query_resources`

**Example**

```js
filecxx_query("filecxx_query_resources", (result) => {
    console.log(result);
});
```

**Result object**

| Property  | Type     | Description                               |
|-----------|----------|-------------------------------------------|
| `error`   | `string` | Query status. `"OK"` indicates success.   |
| `images`  | `array`  | Detected image resources.                 |
| `css`     | `array`  | Detected CSS resources.                   |
| `script`  | `array`  | Detected JavaScript resources.            |
| `fonts`   | `array`  | Detected font resources.                  |
| `customs` | `array`  | Resources detected by user-defined rules. |

---
## Notes

- External message access must be enabled in the extension settings.
- Query results are delivered asynchronously through the callback.
- The returned object structure depends on the query action.
