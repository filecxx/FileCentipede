# Custom download manager


## Template Variables

Template variables are replaced with resource information when the template is evaluated.

| Variable           | Description                                                                                                           | Type      |
|--------------------|-----------------------------------------------------------------------------------------------------------------------|-----------|
| `url`              | Resource URL                                                                                                          | `String`  |
| `page_url`         | URL of the web page containing the resource                                                                           | `String`  |
| `referrer`         | Referrer URL                                                                                                          | `String`  |
| `cookies`          | Cookies associated with the resource                                                                                  | `String`  |
| `user_agent`       | User-Agent string                                                                                                     | `String`  |
| `file_name`        | Resource file name                                                                                                    | `String`  |
| `stream`           | Stream media format, such as `m3u8` or `mpd`                                                                          | `String`  |
| `resid`            | Resource identifier, intended for identification only                                                                 | `String`  |
| `text`             | Resource information, such as resolution and file size                                                                | `String`  |
| `is_audio`         | Whether the resource is audio-only                                                                                    | `Boolean` |
| `extra_data`       | Additional resource metadata, such as `file_size`(Unreliable), `potential_urls` (Array), and `potential_keys` (Array) | `Object`  |
| `service_host`     | Host configured in the service settings                                                                               | `String`  |
| `service_port`     | Port configured in the service settings                                                                               | `Number`  |
| `service_username` | Username configured in the service settings                                                                           | `String`  |
| `service_password` | Password configured in the service settings                                                                           | `String`  |

### Usage Examples

**Access a variable:**

```json
{
    "url": "${url}",
    "page_url": "${page_url}"
}
```

**Access a nested property:**

```json
{
    "url": "${url}",
    "file_size": ${extra_data.file_size}
}
```

Use the appropriate JSON value type. For example, `file_size` is shown without quotes because the example expects a numeric value.

---
## Template Methods

Template methods transform variable values before inserting them into the template.

| Method                      | Description                                            |
|-----------------------------|--------------------------------------------------------|
| `bool(value)`               | Converts a value to a Boolean                          |
| `text(value)`               | Escapes `'`, `"`, and `\` for safe insertion into text |
| `base64(value)`             | Encodes a value using Base64                           |
| `encodeURI(value)`          | Encodes a URI while preserving URI syntax characters   |
| `encodeURIComponent(value)` | Encodes a value for use as a URI component             |

### Usage Examples

**Escape text in JSON strings**

Use `text()` when inserting values such as cookies that may contain characters that would otherwise break the JSON string.

```json
{
    "url": "${url}",
    "cookie": "${text(cookies)}"
}
```

**Encode a value for use in a URL**

Use `encodeURIComponent()` when a value needs to be encoded as an individual URL component, such as a file name.

```json
{
    "url": "${url}",
    "file_name": "${encodeURIComponent(file_name)}"
}
```

**Convert a value to a Boolean**

```json
{
    "is_audio": ${bool(is_audio)}
}
```

---
## Example

[A very basic example of pushing a download task to filecxx desktop app](https://filecxx-extension/eyJ0eXBlIjoiZG93bmxvYWRfbWFuYWdlciIsImRhdGEiOnsibmFtZSI6ImZpbGVjeHgiLCJpY29uIjoiZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFDQUFBQUFnQ0FZQUFBQnplbnIwQUFBSkIwbEVRVlI0QVpSV2VVeFYyUm4vN3Izdm9XeFNVQUYzUllPT0N5cUtvbFlUcmRYWWRHbzF6a2l0aWt0d1ZJcXRTMnpqR0lzYTR6OHV0UmFxQkJkc1VwcG1Zc1RwSDBPeFNvalVCWlZWclRBUlJHT1JWVmFCZCsrNy9mMk9EMW9Hc0RNdjUzdjMzSFB1K2I3ZnR4OWR2dnVQWnh3NFpuaElSbzhlL2ZHMGFkTk80dDBKK2s2RHpMN3RBWDVMb1c0Y01FRVdpSE9wcnE0dUhEUm8wQ2h2Yis5Z3JIRVFDTC9sL0lORXBoLzh3TFBKNzJ6TXJhQ2dvTWxoWVdHN1o4eVk4ZGVvcUtqc09YUG0zSW1PanY2NnBhWGwzKy9ldmF2R054cklCU0pBbmlQaHRlL3h3VTNQRVdyaTl2SHhHVFo5K3ZUMG1UTm5sb3diTis0VU5QNWt3SUFCaTd5OHZLTGRicmNUN3h2bXpadFhNWHYyN0R5NDQ5THc0Y09YNGp3dFJPRDl5dWwzQTRjNUtOd0Nzd1dSa1pINUVCWlRXMXRyTnpjM201aWJFR3I1K2ZsWkxwZkxibTF0RGNUYWNGOWYzMW1EQncrT25UUnBVdGFzV2JPK0luQXdJcEErWmZXNWlBTWNTbmhJU01qY0VTTkdaSUo1OFBMbHk4M0V4RVQ5M0xsempyUzBOTWVWSzFjTVBJMExGeTVvYTlldXRkdmEybXhZdzIyYXB0WFoyV242Ky9zdmg4VnlFUnVqd0xCUEVQMEJvQjh0TUJnOGN1VElQOCtkTzlmMzBxVkwxdEdqUngwclY2NFVNSlhRMEZBSkNBZ1FhQ3ZRVnZidjM2L0Z4OGRyQUtFYmh1SFFOTTFobXFiTDRYQ01oVXYrQWdEa1NSQjg0dlg5NkErQVdvZnBqeTFjdUREczFLbFQ1cWhSb3d3RW1rQ0FJTmdFR2dvRUNNd3Y3ZTN0YWkwMk5sWUFWdUFPMFhWZEFNSnBXWllKdDh3SGlGU0k5QUV4SnJwQjZGajQ1dUFhdFE4Zk8zWnM3TzdkdXdWYUdCUU1mOHZBZ1FQSnVBZFJtRzJUcndneVE0R0NjUEsxOFhRQWJBM0F0b2VHaGs3aEl1ai9BaENZZjlYU3BVc0hvc2lZRUs0aDR1WHg0OGZ5NXMwYkFwSXVnV0RXWXppZFRnWE9zMGdBL0xidTZkT244VlZWVlhsWXAzQzZBbE1SYXFzbStPTmN3MU9wNHUvdkZ4MDlieDVlUllNSkpUTXpVMkppWXVUWXNXTUtBRGY2b3FhbUpncnMybElBT2pvNmFqd0xER3pGMy9QZUF3Q0ZFd1JKQmdWOEwyamtpT0hpTWxuMFJQTHk4cVN1cms0SXhySllZN3BZdkgvQzFHcnk1TWtUQlpBV0F0bDBEMkxpZ2RvVW9RejUzNThTaGdYdkE1RWhTVUVpdnBpN0FrVUNobm5aWVIyMkxnNWQwMHdJWEw5K3ZjVEZ4VWxFUklRS1FESVd6NCtBa0dwU1dGZ28rZm41Z3R3WHBDTjNGWDhBdjhvWFVBL3Q4ZjdlQWhEc1hESFUyTEFyTXZnUEVjTUNJbjhkRlp6OHFidDhaSFY1cVZ2VERiMnpvME5RL2VUdzRjTkNJRWl6YmpOVEVQMk9PSkVUSjA1MGc0UDJKcjdUVWJSdTFkVFUzSVl3YXQvTGRFUm8xSXMwcFpXMy91N2pFR05EYW9UM2d3V0JqcDhONld5MEF1NWw4SkNwaWUxRzZyRUMyakNuS2pZUWJDR3kzY2dRZ1NCQmdWSkJTaGRoajBGbVlNK3FyS3o4SE1JNXlJdlBIa1FBUktXbmxqWit2ak8vZVVtMVMydXhiRnNiRWhTbzMvMUhwdlpsWnBiRDI4ZFhCMlBOMzk5ZmczazFWRVVkNldod0RYWEFPbkRnZ0dSbFphbkNCRkFXNHdIQ3RiS3lzczNvbEhjZ2tjRkhVSmoySEFUQUZXN3E5NnBhYm0yOTN6emhWNFV0QzM1WjFQYURvd1hWYy9ja3hQL3hzOC9pU3M2ZlAxK2JucDdlOE9qUm96cWtVd1g4blk0eWZCbkZwL1hHalJzU0dCam9SaXpZRUc3QS9HMFZGUlV4MFA1UFlPNEVLU1h4N0RXNkFIQkRnWGpUMGxKZFVOMzh6MXlBZVZYWGRQL3JzcktkS1NtcDAzYnMyREZ4M2JwMTRlaDJ3ZWdOWVd2V3JQbnF6Smt6UDNyNTh1VWdXTU9HaThqTGhlRDhXMzE5L2MveHpwd24zNEg0OHdPUlA5M1FSVmdTNFNFMThmeDFmVVNUa2JoUERYZ0Rhc0EzdFVPR0RGa0VFQTlRb05MZ2lxRWc5b1BXTVdQR0ZLUFNGYUphTmdQRUJCU3N5cUZEaHk2Y1BIbnlablJOci9IangwL0ZlVytRQnVvZUZORDk0cGt3VldneUVqL20wMFRqbVFuQmY4ZWQ0QmI4RzBsZlIwUkVhT2dWZ2t1S2hqNHhEdEVlaFNEOUNiUnZoK0R6Mk0rQmEyTHd2QVBBNlNqdGJpaXdZdkhpeFlzOHN0QXhQTE52UENpWVdyTW5CRTZaTWlVSjk0SDdFUHhEVkRVTDNjOUNhelpnZXUzdTNidFNVRkRnQzFmNHZYMzcxbTVvYVBCQ2h6d2JIQnk4QmQvYU9CTU5pNFNqSDR4QlF5dEdPcWZnUmpYZkk2OVBBQlJPeTVpNEMvd1lna3VnL1U1b0pnQmlMVm15eEVEa0d4a1pHY0xnZytZQ2JXWFZxbFdTa0pDZ0hUcDB5SW1PYUNNZ1RRUWsyek1EMDBLcStnT0lOd0M1RUtTZEhnQzlZb0RDdVdlSGg0Zi9mdXJVcVY5Q3F4Q2dOZzhlUEtpakNCblIwZEVDVUFTamhDSTdCQmNTVlFjMmJkb2txMWV2bHUzYnR4c0F6RHNCSzZmZTJOaW9BeERyeFRzOG41YVdsbVpUQ01oTlRmSHNPZURuZEVSNkFxcVlhOHVXTFhacWFxb0RheG91b3JKczJUTFpzMmVQcEtTa3lKRWpSNFJyMEV4VlFHaXN5akhBS3F1Y1BuMWFrcEtTNU9USms5ckVpUk5OM0JzbTFOWFYzYmg5Ky9aRFNLU0xld0JnMU52d3oyOFFLSjhpa0RvVEV4T2R1M2J0VWlEaER0V0lZSDUxK1VDMVUwSlpnbUZTUVFDcWpzbGVnTnVSWEw1OFdRQmFDQTUzUSs3REM0YkFaU3pMa0MvTXVHNFhVQWd2bUI4aFVBNENKVTNwWExGaUJRL3dZMFVVU2kzSmxBdDhncXNRQVBmb21rMXdBMkpBM1pLUUthb3o0aXBub25neEhyNUFldDdEV2NyckJVQmc5czFvTEQ1Z2JNTFhLaDRva0lSRC9RN3U0eXlyb2NCdDZrcUdNcTFBN04yNzE4ek96bmJndlFZWG1yMGVKa3gxTlNVU1RoUWExUGtJYWdLTk5GeS91UzRzTkhoWDdSVUJKUDBSMG94QnhwdVVhc2Z3czQzNE1YTnljaHdvVGkxSTFUV0lnVW93cGN4ZUFMQXVaTUE2em51ZmhlZzJyMTY5YWlHdjNUQ3pqWDV2QXlCSkNjQ2NUNzRyZ2hYY3FQL3VhOWV1bWJnZFc3eEx3dHdPMUlvaTlJM3ZJNXR5SUlSeHBwVEZYQTJpVVJQK1BYLysvQkNDckI3Q3ZCQ0V4dkhqeDQyTkd6ZnEyN1p0MC9idDI2Y2g2cld6WjgrcXRBTkF1WGp4b3BhY25NemMxL0NOdm5YclZoMVhOZ09CYUVEck5nVG1rZHpjM0NnSUx3Ui9DbWRWeGZTL293c0FVV2xvSW5kZ3VnbTRWbjJDdzhsd3gzVzRvckNrcEtUMjVzMmJMZFFPMFcwbEliVUF3STFtNUVJNnRsMi9mcjJxdUxqNFg4ajlQTGppQXJyZ1R4OCtmRGdHK2Y1YmlPS2Rqbko2Q2NkZWR4WndUci93dzdlSTJDOXdpLzBGV3U5S01JcDg5dXpacFBMeThta3c4Y3hYcjE1RnZuanhZajZFeklmRnBtTXRBdThmUWVzcHVEZk9LU29xaW52OStuVUdnckVPVEEwUStWSkJUSHVQL3dBQUFQLy91ZXhnbndBQUFBWkpSRUZVQXdCaUlFNmQvMFNmZEFBQUFBQkpSVTVFcmtKZ2dnPT0iLCJwcm92aWRlciI6ImZpbGVjeHgiLCJwcm92aWRlcl93ZWJzaXRlIjoiaHR0cDovL2ZpbGVjeHguY29tIiwicHVzaF90eXBlIjowLCJkb3dubG9hZF90YXNrIjp0cnVlLCJzdHJlYW1fbWVkaWFfdGFzayI6dHJ1ZSwiY2FsbGJhY2tfbWVzc2FnZV90eXBlIjoxLCJjYWxsYmFja19tZXNzYWdlIjoiRmlsZSBuYW1lOiAke2ZpbGVfbmFtZX08YnIvPlxuVVJMOiAke3VybH0iLCJzZXJ2aWNlX2hvc3QiOiIxMjcuMC4wLjEiLCJzZXJ2aWNlX3BvcnQiOjEwMTExLCJzZXJ2aWNlX3VzZXJuYW1lIjoiIiwic2VydmljZV9wYXNzd29yZCI6IiIsImNvbm5lY3RfdGltZW91dCI6MzAwMCwiaHR0cF9kb3dubG9hZCI6eyJtZXRob2QiOiJGSUxFQyIsInVybCI6Imh0dHA6Ly8ke3NlcnZpY2VfaG9zdH06JHtzZXJ2aWNlX3BvcnR9L3JlcXVlc3QiLCJhdXRob3JpemF0aW9uIjp0cnVlLCJjb250ZW50X3R5cGUiOiJhcHBsaWNhdGlvbi9qc29uIiwiaGVhZGVycyI6IiIsImJvZHkiOiJ7XG5cdFwiQFwiOlwidGFza19hZGRcIixcblx0XCJ1cmlcIjpcIiR7dXJsfVwiLFxuXHRcInVzZXJfYWdlbnRcIjogXCIke3RleHQodXNlcl9hZ2VudCl9XCIsXG5cdFwiY29va2llc1wiOiBcIiR7dGV4dChjb29raWVzKX1cIixcblx0XCJwYWdlX3VybFwiOiBcIiR7cGFnZV91cmx9XCIsXG5cdFwiZmlsZV9uYW1lXCI6IFwiJHtmaWxlX25hbWV9XCIsXG5cdFwiaGVhZGVyc1wiOiAnUmVmZXJlcjogJHtyZWZlcnJlcn0nXG59In0sImh0dHBfc3RyZWFtX21lZGlhIjp7Im1ldGhvZCI6IkZJTEVDIiwidXJsIjoiaHR0cDovLyR7c2VydmljZV9ob3N0fToke3NlcnZpY2VfcG9ydH0vcmVxdWVzdCIsImF1dGhvcml6YXRpb24iOnRydWUsImNvbnRlbnRfdHlwZSI6ImFwcGxpY2F0aW9uL2pzb24iLCJoZWFkZXJzIjoiIiwiYm9keSI6Intcblx0XCJAXCI6XCJ0YXNrX2FkZF9zdHJlYW1cIixcblx0XCJ1cmlcIjpcIiR7dXJsfVwiLFxuXHRcInVzZXJfYWdlbnRcIjogXCIke3RleHQodXNlcl9hZ2VudCl9XCIsXG5cdFwiY29va2llc1wiOiBcIiR7dGV4dChjb29raWVzKX1cIixcblx0XCJwYWdlX3VybFwiOiBcIiR7cGFnZV91cmx9XCIsXG5cdFwiZmlsZV9uYW1lXCI6IFwiJHtmaWxlX25hbWV9XCIsXG5cdFwiYnJvd3Nlcl9pZFwiOiBcIiR7YnJvd3Nlcl9pZH1cIixcblx0XCJyZXNpZFwiOiBcIiR7dGV4dChyZXNpZCl9XCIsXG5cdFwiaGVhZGVyc1wiOiAnUmVmZXJlcjogJHtyZWZlcnJlcn0nXG59In19fQ==)

---
## Notes

- Use `${variable}` to reference a template variable.
- Use `${object.property}` to access a nested object property.
- Use `${method(value)}` to apply a template method.
- Do not enclose values in quotes when the resulting JSON value must be a number, Boolean, or another non-string type.
- Use `text()` for string escaping, not URL encoding. Use `encodeURI()` or `encodeURIComponent()` when URL encoding is required.