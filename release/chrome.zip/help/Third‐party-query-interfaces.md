# Third-Party Query Interfaces

## Interface Types

### 1. Explicit (Window)

When this interface is triggered by clicking a button or an item in the Video Floating Bar, a new window opens with the URL specified in the interface settings.

If the URL contains template variables, they are replaced with values derived from the current webpage's URL.

#### URL Templates

Example template:

```text
http://example/query?url=${url}&xxx=${params.id}&yyy=${params.id2}
```

Example current page URL:

```text
http://127.0.0.1/file.txt?id=123&id2=xxx#aa
```

Available template variables:

| Variable | Value |
|---|---|
| `url` | `http://127.0.0.1/file.txt?id=123#aa` |
| `protocol` | `http:` |
| `host` | `127.0.0.1:8080` |
| `hostname` | `127.0.0.1` |
| `path` | `/file.txt?id=123#aa` |
| `pathname` | `/file.txt` |
| `search` | `?id=123` |
| `hash` | `#aa` |
| `params` | `Object { id: 123, id2: "xxx" }` |

The final URL after template substitution:

```text
http://example/query?url=http%3A%2F%2F127.0.0.1%2Ffile.txt%3Fid%3D123%23aa&xxx=123&yyy=xxx
```

#### Visible Element

Specifies a CSS selector used to identify the element that should be displayed when the window opens. The default selector is `body`.

The selected element is expanded to fill the entire viewport, covering other page elements. This is useful when you only need to display a specific section of a webpage, such as a list of download links.

#### Hidden Elements

Specifies a list of CSS selectors, with one selector per line.

After the target webpage loads, the matching elements are hidden. Use this option to remove unwanted content, such as images, advertisements, or other page elements, and create a cleaner interface.

---

### 2. Data Source

When this interface is triggered by clicking a button or an item in the Video Floating Bar, the configured script is executed and a download list window opens.

The script can retrieve download URLs from external servers using HTTP requests or extract them directly from the current webpage using DOM manipulation.

#### Return Value

The script must return an object containing one or more of the following properties:

- `files`
- `videos`
- `audios`

Each property, when provided, must be an array. The entries in these arrays define the download items displayed in the download list window.

If the script returns a non-object value, it is displayed as an error message.

An empty array does not create a corresponding category in the download list window.

#### Global Functions

```js
copy_to_clipboard(String)
```

Copies the specified string to the clipboard.

#### Global Objects

**localStorage**

[Window.localStorage — MDN](https://developer.mozilla.org/docs/Web/API/Window/localStorage)

**sessionStorage**

[Window.sessionStorage — MDN](https://developer.mozilla.org/docs/Web/API/Window/sessionStorage)

#### Base64

Provides UTF-8-aware Base64 encoding and decoding.

```js
Base64 = {
    encode: function(String), // Encode a UTF-8 string as Base64
    decode: function(String)  // Decode a Base64 string into UTF-8
}
```

#### Page

Provides information about the current webpage and functions for updating the interface.

```js
Page = {
    cookie: String,           // Cookies associated with the current page
    user_agent: String,       // Current page's user-agent string
    progress: Function(text), // Update the loading status text
    url: String,              // Current page URL
    protocol: String,         // URL protocol
    host: String,             // URL host, including the port if present
    hostname: String,         // URL hostname
    path: String,             // URL path
    pathname: String,         // URL pathname
    search: String,           // URL query string
    hash: String,             // URL fragment
    params: Object             // Parsed URL parameters
}
```

Call `Page.progress(text)` to update the loading status displayed while the script executes.

#### UI Functions

**Alert**

```js
ui.alert(text, title = "", type = "information")
```

Displays an alert dialog.

**Prompt**

```js
ui.prompt(text, title = "", default_value = "")
```

Displays a prompt dialog and accepts user input.

**Confirm**

```js
ui.confirm(text, title = "")
```

Displays a confirmation dialog.

#### Download Item Format

Each entry in the `files`, `videos`, or `audios` array must be an object with the following properties:

```js
{
    url: String,             // Required: Download URL
    type: String,            // Optional: File type, such as "mp4" or "m3u8"
    text: String,            // Optional: Display text in the download list
    file_name: String,       // Optional: Downloaded file name
    max_connections: Number, // Optional: Maximum number of download connections
    header: Object           // Optional: HTTP request headers
}
```

**Property details**

| Property          | Description                                                                                                                                  |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------|
| `url`             | The download URL. This property is required.                                                                                                 |
| `type`            | The file type, such as `mp4` or `m3u8`. This is particularly important for HLS playlists (`m3u8`).                                           |
| `text`            | The text displayed for the download item.                                                                                                    |
| `file_name`       | The preferred file name for the downloaded file.                                                                                             |
| `max_connections` | The maximum number of connections the download manager should use. This setting is not supported by the browser's built-in download manager. |
| `header`          | An object containing HTTP request headers, typically including `referer`, `user-agent`, and `cookie`.                                        |

#### Cookie Handling

To include cookies in the HTTP request headers, you can either provide a cookie string or set `cookie` to `true`.

When set to `true`, the application attempts to retrieve the cookies associated with the target URL automatically.

For example:

```js
{
    url: "http://127.0.0.1/1.txt",
    header: {
        cookie: true
        // Alternatively, use Page.cookie to pass the current page's cookies.
    }
}
```

#### Code Example

```js
videos = [
    {
        url: "http://127.0.0.1/xxxxx",
        type: "mp4",
        text: "Test result"
    }
];

audios = [];

for (let i = 0; i < 100; ++i) {
    Page.progress("Loading " + i + "%");
    sleep(20);
}

Page.progress("Fetching...");

http = HTTP.get(
    "https://127.0.0.1/file?url=" + encodeURIComponent(Page.url),
    {
        headers: {
            referer: "https://127.0.0.1"
        }
    }
);

if (http.status === 200) {
    json = http.JSON;

    if (!json || !is_array(json.videos)) {
        return "Data error";
    }

    for (let i = 0; i < json.videos.length; ++i) {
        video = json.videos[i];

        videos.push({
            text: video.text,
            url: video.url,
            header: {
                referer: "https://127.0.0.1",
                cookie: Page.cookie
            }
        });
    }
} else {
    // return "Data error";
}

return {
    videos: videos,
    audios: audios
};
```

For additional scripting documentation and examples, see the [TrashScript Wiki](https://github.com/filecxx/TrashScript/wiki).

---

## File Type

The file type determines how download items are presented.

When the interface type is **Data Source** and the file type is **Videos & Audios**, the extracted video and audio download links are displayed not only in the download list window but also in the extension popup and Collector mode.

---

## Trigger

The **Trigger** setting determines how the interface is activated.

**Video Floating Bar**

When a video element is detected on a webpage, a Video Floating Bar is created automatically. A submenu item using the interface's configured name and icon is added to the bar. Clicking this item triggers the interface.

**Create Button**

A button is inserted into the specified location on the webpage when the relevant element or page is detected. Clicking the button triggers the interface.

Both trigger options can be enabled simultaneously.

---

## Hosts

The **Hosts** setting specifies which websites can activate the interface. Enter one host per line.

Each entry can be a domain name or an IP address, without a port number.

When the browser opens a matching webpage, a button or Video Floating Bar is created according to the configured trigger options. The interface can also be activated when a matching host is found inside an iframe on the page.

If the **Paths** setting is configured, the URL must also satisfy the specified path-matching rules.

---

## Paths

The **Paths** setting specifies which URL paths are eligible for the interface. Enter one path per line.

Example:

```text
/file?xx=123
```

Multiple entries are supported, typically using regular expressions to match different URL patterns.

If this setting is empty, no path matching is performed, and any path on a matching host is considered valid.
