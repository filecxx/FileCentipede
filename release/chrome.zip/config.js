
var config={software_name:chrome.i18n.getMessage("appname"),class_prefix:"filec",scheme_c:"filec",scheme_u:"fileu",video_id_name:"filec_captured_id_",service_port:10111};