Action#act_normal_add
{
    text:"${add}"
    icon:"icons/16/add_file.svg"
}

Action#act_normal_remove
{
    text:"${remove}"
    icon:"icons/16/delete.svg"
}

Action#act_normal_clear
{
    text:"${clear}"
    icon:"icons/16/delete_all.svg"
}

Action#act_normal_merge
{
    text:"${merge}"
    icon:"icons/16/save_as.svg"
    enable:false
}


//------------------
Action#act_av_add
{
    text:"${add}"
    icon:"icons/16/add_file.svg"
}

Action#act_av_remove
{
    text:"${remove}"
    icon:"icons/16/delete.svg"
}

Action#act_av_clear
{
    text:"${clear}"
    icon:"icons/16/delete_all.svg"
}

Action#act_av_merge
{
    text:"${merge}"
    icon:"icons/16/save_as.svg"
    enable:false
}


//------------------
#normal_merge
{
    text:"${normal_merge}"
    icon:"icons/16/data.svg"
    layout:VBoxLayout
    ToolBar
    {
        icon-size:16
        button-style:TextBesideIcon
        
        ${#act_normal_add}
        ${#act_normal_remove}
        ${#act_normal_clear}
        ---
        ${#act_normal_merge}
    }
    Table#normal_files
    {
        name:files
        sortable:false
        stripe:true
        editable:false
        wordwrap:false
        selection:rows
        numbers:true
        stretch-last-section:true
        columns-height:26
        columns:{
            {name:size,text:"${size}",width:120}
            {name:path,text:"${path}"}
        }
        context-menu:{
            ${#act_normal_add}
            ${#act_normal_remove}
            ${#act_normal_clear}
            ---
            ${#act_normal_merge}
        }
    }
    
}

#video_audio_merge
{
    text:"${video}+${audio} ${merge}"
    icon:"icons/mimetypes/24/video-mp4.png"
    layout:VBoxLayout
    
    ToolBar
    {
        icon-size:16
        button-style:TextBesideIcon
        
        ${#act_av_add}
        ${#act_av_remove}
        ${#act_av_clear}
        ---
        ${#act_av_merge}
    }
    Table#av_files
    {
        name:av_files
        sortable:false
        stripe:true
        editable:false
        wordwrap:false
        selection:rows
        numbers:true
        stretch-last-section:true
        columns-height:26
        columns:{
            {name:size,text:"${size}",width:120}
            {name:path,text:"${path}"}
        }
        context-menu:{
            ${#act_av_add}
            ${#act_av_remove}
            ${#act_av_clear}
            ---
            ${#act_av_merge}
        }
    }
    Widget#av_loading
    {
        css:"background:transparent"
        layout:{
            type:VBoxLayout
            column:1
            align:hcenter
        }
        visible: false
        Img{src:"ui/css/images/loading_clock.gif"}
        "${transcoding}"
    }
}

Dialog#main
{
    title:"${file_merge}"
    layout:VBoxLayout
    droppable:true
    w:650
    h:400

    Tab#tab{
        ${#normal_merge}
        ${#video_audio_merge}
    }
    StatusBar#status{
        message-timeout:3000
    }
}
 
 
