.vboxlayout2
{
    type:VBoxLayout
    margin:1
    spacing:0
}

Action#act_torrent_spider_start
{
    icon:"icons/24/start.svg"
    text:"${start}"
}

Action#act_torrent_spider_stop
{
    icon:"icons/24/stop.svg"
    text:"${stop}"
}


#torrent_spider
{
    text:"${spider}"
    icon:"icons/16/torrent.svg"
    layout:${.vboxlayout2}


    HBoxLayout
    {
        ToolBar
        {
            icon-size:24
            button-style:TextBesideIcon

            ${#act_torrent_spider_start}
            ${#act_torrent_spider_stop}
        }
    }
    Table#torrents
    {
        name:torrents
        sortable:true
        stripe:true
        editable:true
        wordwrap:false
        selection:rows
        icon-size:24
        columns-height:26
        columns:{
            {name:torrent_name,text:"${file_name}",width:180}
            {name:hash,text:"HASH",width:280}
        }
    }
    StatusBar
    {
        Label{"${state}:"} Label{
            name:state
            text:"${none}"
        }
    }

}


#peers
{
    text:"${peers}"
    icon:"icons/16/users.svg"
    layout:${.vboxlayout2}

}

#search
{
    text:"${search}"
    icon:"icons/16/search.svg"
    layout:${.vboxlayout2}

}

#storage
{
    text:"${storage}"
    icon:"icons/16/data.svg"
    layout:${.vboxlayout2}

}

#log
{
    text:"${log}"
    icon:"icons/mimetypes/24/text-x-plain.png"
    layout:${.vboxlayout2}

}

#help
{
    text:"${help}"
    icon:"icons/16/about.svg"
    layout:${.vboxlayout2}

}

Dialog#main
{
    title:"DHT ${network}"
    width:800
    height:400
    layout:VBoxLayout

    Tab
    {
        ${#torrent_spider}
        ${#peers}
        ${#search}
        ${#storage}
        ${#log}
        ${#help}
    }


}
