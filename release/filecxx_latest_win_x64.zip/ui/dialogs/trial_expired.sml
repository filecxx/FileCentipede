Dialog#main
{
    title:"${free_trial_expired}"
    w:480
    h:180
    layout:HBoxLayout
 
    GroupBox
    {
        title: "${software_name_}"
        layout: VBoxLayout
        
        TextEdit{
            readonly:true
            viewonly:true
            "${trial_expired_text_}"
        }
        TextEdit{
            readonly:true
            viewonly:true
            "(${trial_expired_title_})"
        }
  
        <==>
    }
    
    VBoxLayout
    {
        margin:5
        Button#buy{
            icon:"icons/16/donate.svg"
            text:"${buy}"
        }
        Button#enter_license{
            icon:"icons/16/paste.svg"
            text:"${enter_license}"
        }
        Button{
            icon:"icons/16/close.svg"
            text:"${close} (&C)"
            click:$close{#main}()
        }
        <==>
    }
}