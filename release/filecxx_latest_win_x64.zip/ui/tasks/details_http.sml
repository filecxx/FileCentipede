DetailBar#details
{
    expanded:false
    
    {
        subset:attributes
        text:"${attributes}"
        icon-size:16
        icon:"icons/16/attributes.svg"
        layout:{
            type:VBoxLayout
            margin:8
        }
        GridLayout
        {
            column:6
            
            "${catalog}:" LineView{name:catalog}
            "${size}:" LineView{name:file_size,format:bytes}
            "${downloaded}:" LineView{name:downloaded,format:bytes}
            "${etag}:" LineView{name:etag}
            "${connectivity}:" LineView{name:connectivity}
            "${connect_timeout}:" LineView{name:connect_timeout,format:"number ms"}
            "${connections}:" LineView{name:connections}
            "${max_connections}:" LineView{name:max_connections}
            "${max_retry}:" LineView{name:max_retry}
            "${max_redirect}:" LineView{name:max_redirect}
            "${speed_limit_download}:" LineView{name:speed_limit_download,format:"number KB/s"}
            "${resumable}:" LineView{name:resumable}
            "${auto_rename_file}:" LineView{name:auto_rename_file}
            "${ignore_remote_modified}:" LineView{name:ignore_remote_modified}
            "${ignore_server_busy}:" LineView{name:ignore_server_busy}
            "${ignore_http_error}:" LineView{name:ignore_http_error}
            "${last_modified_time}: " LineView{name:last_modified,format:datetime}
            "${time_create}:" LineView{name:time_create,format:datetime}
            "${time_start}:" LineView{name:time_start,format:datetime}
            "${time_end}:" LineView{name:time_end,format:datetime}
        }
    
    }
    /*
    {
        subset:information
        text:"${info}"
        icon-size:16
        icon:"icons/16/info.svg"
        layout:{
            type:VBoxLayout
            margin:2
        }
        
        Edit{
            name:torrent_comment
            readonly:true
        }
    }
    */ 
    {
        subset:request
        text:"${request}"
        icon-size:16
        icon:"icons/16/request.svg"
        layout:VBoxLayout
        
        HBoxLayout
        {
            "${proxy}:" LineView{name:proxy}
            "${proxy_mode}:" LineView{name:proxy_mode}
            "${method}:" LineView{name:method}
            
            "Content-Type:" LineView{name:content_type}
        }
        GridLayout
        {
            column:2
     
            "${address}:" HBoxLayout{
                LineEdit#http_uri{
                    name:uri
                    readonly:true
                }
                ToolButton
                {
                    icon:"icons/16/copy.svg"
                    click:{
                        $copy(${#http_uri})
                    }
                }
            }
            
            "${page_url}:" HBoxLayout
            {
                LineEdit#page_url{
                    name:page_url
                    readonly:true
                }
                ToolButton{
                    icon:"icons/16/web.svg"
                    click:$open-url(${#page_url})
                }
            }
            "User Agent:" LineEdit{
                name:user_agent
                readonly:true
            }
            "Cookies:" TextEdit{
                name:cookies
                readonly:true
            }
            "Headers:" TextEdit{
                name:headers
                readonly:true
            }
        }
   
    }
    {
        subset:connections
        text:"${connections}"
        icon-size:16
        icon:"icons/16/connect.svg"
        layout:{
            type:VBoxLayout
            margin:1
        }
        Table.table#connections
        {
            sortable:true
            stripe:true
            editable:false
            grid:false
            numbers:true
            selection:rows
            min-height:100
            columns:{
                {name:"state",width:140,text:"${state}"}
                {name:"begin",width:120,text:"${begin}",format:bytes}
                {name:"end",width:120,text:"${end}",format:bytes}
                {name:"transferred",width:120,text:"${transferred}",format:bytes}
                {name:"progress",width:100,text:"${progress}", format:"progress",align:"right"}
                {name:"ping", text:"Ping", width:80, format:"ms",align:"right"}
                {name:"speed", text:"${speed}", width:100, format:"bytes/s",align:"right"}
                {name:"proxy",width:120,text:"${proxy}",align:"center"}
            }
        }
    }
    {
        subset:blocks
        text:"${blocks}"
        icon-size:16
        icon:"icons/16/blocks.svg"
        layout:{
            type:VBoxLayout
            margin:1
        }
        Blocks{
            min-height:120
            name:blocks
        }
    }
    {
        subset:mirrors
        text:"${mirrors}"
        icon-size:16
        icon:"icons/16/circle.svg"
        layout:{
            type:VBoxLayout
            margin:2
        }

        Table.table#mirrors
        {
            stretch-last-section:true
            sortable:true
            stripe:true
            editable:false
            grid:false
            numbers:true
            selection:rows
            min-height:100
            columns:{
                {name:"state",width:160,text:"${state}"}
                {name:"ping", text:"Ping", width:120, format:"ms",align:"right"}
                {name:"transferred", text:"${transferred}", width:120, format:"bytes",align:"right"}
                {name:"host", text:"${host}", width:280}
            }
        }
       
    }
} 
