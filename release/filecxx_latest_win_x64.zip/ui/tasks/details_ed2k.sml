DetailBar#details
{
}
