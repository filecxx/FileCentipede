Dialog#main
{
    layout:VBoxLayout
}
