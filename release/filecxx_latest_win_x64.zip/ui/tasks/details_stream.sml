DetailBar#details
{
    expanded:false
    
    {
        subset:attributes
        text:"${attributes}"
        icon-size:16
        icon:"icons/16/attributes.svg"
        layout:{
            type:VBoxLayout
            margin:10
        }
        GridLayout
        {
            column:6

            "${catalog}:" LineView{name:catalog}
            "${size}:" LineView{name:file_size,format:bytes}
            "${downloaded}:" LineView{name:downloaded,format:bytes}
            "${connectivity}:" LineView{name:connectivity}
            "${connect_timeout}:" LineView{name:connect_timeout,format:"number ms"}
            "${connections}:" LineView{name:connections}
            "${max_connections}:" LineView{name:max_connections}
            "${max_retry}:" LineView{name:max_retry}
            "${speed_limit_download}:" LineView{name:speed_limit_download,format:"number KB/s"}
            "${merge_segments}:" LineView{name:auto_merge}
            "${merge} ${video} + ${audio}:" LineView{name:video_audio_merge}
            "${auto_rename_file}:" LineView{name:auto_rename_file}
            "${ignore_server_busy}:" LineView{name:ignore_server_busy}
            
            "${time_create}:" LineView{name:time_create,format:datetime}
            "${time_start}:" LineView{name:time_start,format:datetime}
            "${time_end}:" LineView{name:time_end,format:datetime}
        }
   
    }
    {
        subset:request
        text:"${request}"
        icon-size:16
        icon:"icons/16/request.svg"
        layout:{
            type:VBoxLayout
            margin:10
        }
        HBoxLayout
        {
            "${proxy}:" LineView{name:proxy}
            "${proxy_mode}:" LineView{name:proxy_mode}
            "${method}:" LineView{name:method}
            "Content-Type:" LineView{name:content_type}
        }
        GridLayout
        {
            column:2

            "${address}:" HBoxLayout
            {
                LineEdit#stream_uri{
                    name:uri
                    readonly:true
                }
                ToolButton
                {
                    icon:"icons/16/copy.svg"
                    click:{
                        $copy(${#stream_uri})
                    }
                }
            }
            "${page_url}:" HBoxLayout
            {
                LineEdit#page_url{
                    name:page_url
                    readonly:true
                }
                ToolButton{
                    icon:"icons/16/web.svg"
                    click:$open-url(${#page_url})
                }
            }
            "User Agent:" LineEdit{
                name:user_agent
                readonly:true
            }
            "Cookies:" TextEdit{
                name:cookies
                readonly:true
            }
            "Headers:" TextEdit{
                name:headers
                readonly:true
            }
        }
    }
    {
        subset:blocks
        text:"${blocks}"
        icon-size:16
        icon:"icons/16/blocks.svg"
        layout:{
            type:VBoxLayout
            margin:1
        }
        Blocks{
            min-height:120
            name:blocks
        }
    }
    {
        subset:connections
        text:"${connections}"
        icon-size:16
        icon:"icons/16/connect.svg"
        layout:{
            type:VBoxLayout
            margin:1
        }
        Table.table#connections
        {
            stretch-last-section:true
            sortable:true
            stripe:true
            editable:false
            grid:false
            numbers:true
            wordwrap:false
            selection:rows
            min-height:100
            columns:{
                {name:"state",width:140,text:"${state}"}
                {name:"file_size",width:120,text:"${size}", format:bytes}
                {name:"transferred",width:120,text:"${transferred}", format:bytes}
                {name:"progress",width:100,text:"${progress}", format:"progress",align:"right"}
                {name:"ping", text:"Ping", width:80, format:"ms",align:"right"}
                {name:"speed", text:"${speed}", width:100, format:"bytes/s",align:"right"}
                {name:"proxy",width:140,text:"${proxy}",align:"center"}
                {name:"uri",width:180,text:"URI"}
            }
        }
    }
}
