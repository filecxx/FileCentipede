
EditDialog#dialog_http_mirror_edit
{
    width:450
    height:400
    title-add:"${add}"
    title-edit:"${edit}"
    form:${#dialog_http_mirror_edit}
    layout:VBoxLayout
    buttons:default

    GridLayout
    {
        column:2

        "${name}:" LineEdit{
            name:name
            placeholder:"${name} (${optional})"
        }
        "${host} (${origin}):" LineEdit{
            name:host
            value:""
            placeholder:"IP / ${domain}"
        }
        "${mode}:" HBoxLayout
        {
            ComboBox
            {
                name: mode
                vtype: index
                stretch: expand
                size-adjust: content

                "${round_robin}"
            }
            "${proxy}:" ComboBox
            {
                name: proxy
                vtype: index
                stretch: expand
                size-adjust: content

                "${enable}"
                "${disable}"
            }
        }
        
       
        "${path}:" ComboBox
        {
            name: path
            vtype: index
            stretch: expand
            size-adjust: content

            "${replace_origin_host}"
            "${prepend_before_origin_url}"
            "${replace_origin_url}"
        }
    }
    /*
    CheckBox.uncheck{
        name:subdomains
        value:false
        text:"${including_subdomains}"
    }*/
    TextEdit{
        name:servers
        placeholder:"${http_mirrors_placeholder}"
    }
}