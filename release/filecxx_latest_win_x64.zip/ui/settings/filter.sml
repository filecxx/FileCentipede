Action#act_add
{
   text:"${add}"
   icon:"icons/24/add.svg"
}

Action#act_edit{
    text:"${edit}"
    icon:"icons/24/edit.svg"
}

Action#act_remove{
    text:"${remove}"
    icon:"icons/24/delete.svg"
    trigger:$remove-selected-rows{#torrent_files_filter}()
}


EditDialog#dialog_torrent_files_filter
{
    layout:VBoxLayout
    width:400
    height:200
    title-add:"${add}"
    title-edit:"${edit}"
    form:${#dialog_torrent_files_filter}
    buttons:default
    GridLayout
    {
        column:2
        
        "${rule_name}:" LineEdit{
            name:name
            placeholder:"${filter_rule_name_placeholder_}"
        }
        "${rule}:" TextEdit{
            name:rule
            placeholder:"${filter_rule_placeholder_}"
        }
    }
    
}


#torrent_files
{
    text:"${rule}"
    layout:{
        type:VBoxLayout
        spacing:0
        margin:2
    }
    ToolBar
    {
        icon-size:24
        button-style:TextBesideIcon

        ${#act_add}
        ${#act_edit}
        ${#act_remove}
    }
    Table#torrent_files_filter
    {
        name:torrent_files
        sortable:true
        stripe:true
        editable:false
        stretch-last-section:true
        selection:rows
        vtype:pairs
        columns-height:26
        columns:{
            {name:name,text:"${rule_name}",width:120}
            {name:rule,text:"${rule}",width:160}
        }
        double-click:$trigger{#act_edit}()
        context-menu:
        {
            ${#act_add}
            ${#act_edit}
            ${#act_remove}
        }
    }
    
}

#file_names
{
    text:"${file_names}"
    layout:VBoxLayout

    TextEdit{
        name:file_names
        placeholder:"${filter_file_names_placeholder_}"
    }
}

#help
{
    text:"${help}"
    layout:VBoxLayout
    Edit{
        viewonly:true
        "${setting_filter_help_}"
    }
}


Dialog#main
{
    title:"${filter}"
    width:600
    height:400
    layout:VBoxLayout
    
    Tab#tabs
    {
        ${#torrent_files}
        ${#file_names}
        ${#help}
    }
    HBoxLayout
    {
        <==>
        Button#save{
            text:"${save}"
            icon:"icons/16/save.svg"
        }
        Button{
            text:"${cancel}"
            icon:"icons/16/cancel.svg"
            click:$close{#main}()
        }
    }
}  
